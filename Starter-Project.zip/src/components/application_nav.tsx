import React from 'react'

const application_nav = () => {
  return (
    <div>application_nav</div>
  )
}

export default application_nav