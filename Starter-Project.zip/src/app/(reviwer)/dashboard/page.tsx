import ReviewerDashboard from '@/components/ReviewerDashboard'
import React from 'react'

const page = () => {
  return (
    <ReviewerDashboard />
  )
}

export default page