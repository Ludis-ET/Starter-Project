import BodyOne from "./components/mainPageComponents/BodyOne";

export default function Home() {
  return (
    <div className="min-h-screen">
      <BodyOne />
    </div>
  );
}
