import Image from "next/image";
// import Header from "./components/Header"
import ApplicantForm from "./components/ApplicantsForm";
import SignInForm from "./components/SignInForm";
import Header from "./components/Header";
import ForgotPasswordForm from "./components/ForgotPassword";
import SetNewPasswordForm from "./components/SetNewPasswordFormData";
import NotFoundPage from "@/components/NotFoundPage";
import ApplicationForm from "./components/ApplicationFormData";
import SuccessApplication from "./components/SuccessReset";
export default function Home() {
  return (
    <>
      <Header />
      {/* <ApplicantForm /> */}
      {/* <SignInForm /> */}
      {/* <ForgotPasswordForm /> */}
      {/* <SetNewPasswordForm /> */}
      {/* <NotFoundPage /> */}
      {/* <ApplicationForm /> */}
      {/* <SuccessApplication /> */}
    </>
  );
}