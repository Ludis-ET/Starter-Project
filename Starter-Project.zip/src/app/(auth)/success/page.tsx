import Header from '@/app/components/Header'
import SuccessReset from '@/app/components/SuccessReset'
import React from 'react'

const Succes = () => {
  return (
    <>
        <Header />
        <SuccessReset />
    </>
  )
}

export default Succes